from . import models



# __init__.py
# Tells Python to treat this folder as a package.
# Also loads everything inside our models folder.



