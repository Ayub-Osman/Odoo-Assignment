# __manifest__.py
# This is the module's ID card. Odoo reads this file first
# to understand what this module is and what it needs.

{
    'name': 'Meter Reading Invoice',
    'version': '17.0.1.0.0',
    'category': 'Accounting',
    'depends': ['account'],
    'data': [
        'views/account_move_views.xml',
        'report/invoice_report.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
