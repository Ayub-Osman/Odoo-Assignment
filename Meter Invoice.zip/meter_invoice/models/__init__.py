
#models/__init__.py
#Tells Python to load our account_move_line file
#when Odoo loads the models folder.

from . import account_move_line
