# models/account_move_line.py
# This file extends Odoo's existing invoice line model.
# We are adding meter reading fields and the logic behind them.

from odoo import models, fields, api


class AccountMoveLine(models.Model):
    # _inherit tells Odoo to extend the existing invoice line model
    # instead of creating a new one
    _inherit = 'account.move.line'

    # FIELDS

    previous_reading = fields.Float(
        string='Previous',
        default=0.0,
        # readonly in XML - fetched automatically from last invoice
    )

    new_reading = fields.Float(
        string='New',
        default=0.0,
        # user types this value each month
    )

    actual_reading = fields.Float(
        string='Actual',
        default=0.0,
        store=True,
        # stored so reports can access it
    )

    # METHODS

    def _get_previous_reading(self):
        # finds the client's last posted invoice and returns
        # its new_reading value to use as this month's previous reading

        partner = self.move_id.partner_id
        product = self.product_id
        current_invoice = self.move_id

        # if no client or product selected yet return 0
        if not partner or not product:
            return 0.0

        # use _origin.id to get real saved ID
        # avoids crash when invoice is not saved yet
        previous_invoice = self.env['account.move'].search([
            ('partner_id', '=', partner.id),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('id', '!=', current_invoice._origin.id),
        ], order='invoice_date desc', limit=1)

        # no previous invoice means this is a new client
        if not previous_invoice:
            return 0.0

        # find the line with the same product in previous invoice
        previous_line = previous_invoice.invoice_line_ids.filtered(
            lambda l: l.product_id == product
        )

        # product not found in previous invoice
        if not previous_line:
            return 0.0

        # return last month's new_reading as this month's previous
        return previous_line[0].new_reading

    @api.onchange('new_reading')
    def _onchange_new_reading(self):
        # runs when user types new reading on the form
        # temporarily shows previous and actual before saving
        previous = self._get_previous_reading()
        self.previous_reading = previous
        actual = self.new_reading - previous
        self.actual_reading = max(actual, 0.0)
        if self.actual_reading > 0:
            self.quantity = self.actual_reading

    @api.model_create_multi
    def create(self, vals_list):
        # override create to save meter readings when line is created
        records = super().create(vals_list)
        for record in records:
            if record.new_reading:
                previous = record._get_previous_reading()
                actual = max(record.new_reading - previous, 0.0)
                record.previous_reading = previous
                record.actual_reading = actual
        return records

    def write(self, vals):
        # override write to save meter readings when line is updated
        result = super().write(vals)
        if 'new_reading' in vals:
            for line in self:
                previous = line._get_previous_reading()
                actual = max(line.new_reading - previous, 0.0)
                line.previous_reading = previous
                line.actual_reading = actual
        return result
